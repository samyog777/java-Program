//package Week_3_workshop;
//import java.util.Scanner;
//import java.util.Arrays;
//
//public class question5 {
//
//	public static void main(String[] args) {
//		Scanner Scan = new Scanner (System.in);
//		int size = 5;
//		int[] array = new int[size]; 
//		System.out.println("Enter "+ size + "integer: ");
//		size = Scan.nextInt();
//
//	}
//
//}
package Week_3_workshop;
import java.util.Scanner;
import java.util.Arrays;

public class question5 {
    public static void main(String[] args) {
        Scanner Scan = new Scanner(System.in);
        
        int size = 5;
        int[] array = new int[size];
        System.out.println("Enter " + size + " integers:");
        for (int i = 0; i < size; i++) {
            array[i] = Scan.nextInt();
        }
        
        System.out.println("Array as entered:");
        System.out.print(Arrays.toString(array));
        
        System.out.println("\nArray elements in reverse order:");
        for (int i = array.length-1; i >= 0; i--) {
            System.out.print(array[i] + " ");
        }
        
        Scan.close();
    }
}

